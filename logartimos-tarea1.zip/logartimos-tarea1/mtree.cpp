#include "mtree.hpp"


// Función para calcular la distancia euclidiana entre dos puntos.
